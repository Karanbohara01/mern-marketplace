// mocha.config.mjs
export default {
  loader: "ts-node/esm",
  spec: "tests/**/*.spec.ts",
  timeout: 10000,
};
